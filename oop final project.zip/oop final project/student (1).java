/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package alexuniversity;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Date;
import java.util.Map;
import java.io.Serializable;


/**
 *
 * @author Lenovo
 */
public class student extends user implements Serializable  {
  
    private String studentid;
    private String admissiondate;
    private String academicstatus;
    private List<enrollment> enrollments;
    private Map<course, Integer> attendance;

    public student(String userid, String username, String password, String name, String email, String contactinfo) {
        super(userid, username, password, name, email, contactinfo);
        this.studentid = "S" + userid;
        this.admissiondate = "";
        this.academicstatus = "Active";
        this.enrollments = new ArrayList<>();
        this.attendance = new HashMap<>();
    }

    @Override
    public void showmenu() {
        System.out.println("\nStudent Menu:");
        System.out.println("1. Register for a course");
        System.out.println("2. Drop a course");
        System.out.println("3. View grades");
        System.out.println("4. Calculate GPA");
        System.out.println("5. Mark Attendance");
        System.out.println("6. Logout");
    }

    @Override
    public String tocv() {
        return "studentid=" + studentid + ",username=" + username + ",password=" + password + ",name=" + name + ",email=" + email + ",contactinfo=" + contactinfo + ",admissiondate=" + admissiondate + ",academicstatus=" + academicstatus;
    }
    
    


    public void registercourse(course c) {
        for (enrollment e : enrollments) {
            if (e.getCourse().equals(c) && e.getStatus().equals("Active")) {
                System.out.println("Already enrolled in this course.");
                return;
            }
            if (e.getCourse().getSchedule().equals(c.getSchedule()) && e.getStatus().equals("Active")) {
                System.out.println("Schedule conflict with " + e.getCourse().getTitle());
                return;
            }
        }

        if (!c.isPrerequisiteSatisfied(this)) {
            System.out.println("Missing prerequisites.");
            return;
        }

        if (c.addStudent(this)) {
            enrollment newEnrollment = new enrollment(this, c, new Date(), null, "Active");
            enrollments.add(newEnrollment);
            attendance.put(c, 0);
        }
    }

    public void dropcourse(course c) {
        for (enrollment e : enrollments) {
            if (e.getCourse().equals(c) && e.getStatus().equals("Active")) {
                c.removeStudent(this);
                e.withdraw();
                System.out.println("Course " + c.getTitle() + " dropped successfully.");
                attendance.remove(c);
                return;
            }
        }
        System.out.println("You are not enrolled in this course.");
    }

    public void viewGrades() {
        boolean found = false;
        for (enrollment e : enrollments) {
            if (e.getGrade() != null) {
                System.out.println("Course: " + e.getCourse().getTitle() + " | Grade: " + e.getGrade());
                found = true;
            }
        }
        if (!found) {
            System.out.println("No grades available.");
        }
    }

    public double calculateGPA() {
        double totalPoints = 0;
        int count = 0;

        for (enrollment e : enrollments) {
            String grade = e.getGrade();
            if (grade != null) {
                switch (grade.toUpperCase()) {
                    case "A": totalPoints += 4.0; break;
                    case "B": totalPoints += 3.0; break;
                    case "C": totalPoints += 2.0; break;
                    case "D": totalPoints += 1.0; break;
                    case "F": totalPoints += 0.0; break;
                }
                count++;
            }
        }

        if (count == 0) {
            System.out.println("No grades available to calculate GPA.");
            return 0.0;
        }

        double gpa = totalPoints / count;
        System.out.printf("Your GPA is: %.2f\n", gpa);
        return gpa;
    }

    public boolean hasCompletedCourse(String courseId) {
        for (enrollment e : enrollments) {
            if (e.getCourse().getCourse_id().equals(courseId)) {
                String grade = e.getGrade();
                if (grade != null && isPassingGrade(grade)) {
                    return true;
                }
            }
        }
        return false;
    }

    private boolean isPassingGrade(String grade) {
        switch (grade.toUpperCase()) {
            case "A": case "B": case "C": return true;
            default: return false;
        }
    }

    public void markAttendance(course c) {
        if (!attendance.containsKey(c)) {
            System.out.println("You are not enrolled in this course.");
            return;
        }
        int current = attendance.get(c);
        attendance.put(c, current + 1);
        System.out.println("Attendance marked for course: " + c.getTitle());
    }

    public int getAttendance(course c) {
        return attendance.getOrDefault(c, 0);
    }

    public List<enrollment> getEnrollments() {
        return enrollments;
    }

    public void addEnrollment(enrollment e) {
        enrollments.add(e);
        attendance.put(e.getCourse(), 0);
    }
}

    
   
    

