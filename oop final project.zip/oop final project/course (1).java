/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package alexuniversity;
import java .util.ArrayList;
import java .util.List;
import java.io.Serializable;


/**
 *
 * @author Lenovo
 */
public class course implements Serializable{
    
     private String course_id;
    private String title;
    private String description;
    private int credit_hours;
    private List<course> prerequisites;
    private String schedule;
    private faculty instructor;
    private List<student> enrolledStudents;
    private int maxCapacity;
    
    public course(String courseid, String title) {
        this.course_id = courseid;
        this.title = title;
        this.enrolledStudents = new ArrayList<>();
        this.prerequisites = new ArrayList<>();
    }

    public course(String description, int credit_hours, List<course> prerequisites, String schedule, faculty instructor, List<student> enrolledStudents, int maxCapacity) {
        this.description = description;
        this.credit_hours = credit_hours;
        this.prerequisites = prerequisites != null ? prerequisites : new ArrayList<>();
        this.schedule = schedule;
        this.instructor = instructor;
        this.enrolledStudents = enrolledStudents != null ? enrolledStudents : new ArrayList<>();
        this.maxCapacity = maxCapacity;
    }

    public course(String courseCode, String courseName, int creditHours) {
    this.course_id= courseCode;
    this.title = courseName;
    this.credit_hours = creditHours;
    this.enrolledStudents = new ArrayList<>();
    this.prerequisites = new ArrayList<>();
    this.maxCapacity = 50; 
}

    

    public boolean addStudent(student student) {
        if (enrolledStudents.size() < maxCapacity && isPrerequisiteSatisfied(student)) {
            enrolledStudents.add(student);
            System.out.println("Student " + student.getName() + " enrolled in " + title);
            return true;
        }
        System.out.println("Cannot enroll student " + student.getName() + " in " + title);
        return false;
    }

    public boolean removeStudent(student student) {
        if (enrolledStudents.remove(student)) {
            System.out.println("Student " + student.getName() + " removed from " + title);
            return true;
        }
        return false;
    }

    public boolean isPrerequisiteSatisfied(student student) {
        if (prerequisites == null || prerequisites.isEmpty()) {
            return true;
        }

        for (course prerequisiteCourse : prerequisites) {
            if (!student.hasCompletedCourse(prerequisiteCourse.getCourse_id())) {
                return false;
            }
        }

        return true;
    }

    public int getAvailableSeats() {
        return maxCapacity - enrolledStudents.size();
    }

    public String getCourse_id() {
        return course_id;
    }

    public void setCourse_id(String course_id) {
        this.course_id = course_id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public int getCredit_hours() {
        return credit_hours;
    }

    public void setCredit_hours(int credit_hours) {
        this.credit_hours = credit_hours;
    }

    public List<course> getPrerequisites() {
        return prerequisites;
    }

    public void setPrerequisites(List<course> prerequisites) {
        this.prerequisites = prerequisites;
    }

    public String getSchedule() {
        return schedule;
    }

    public void setSchedule(String schedule) {
        this.schedule = schedule;
    }

    public faculty getInstructor() {
        return instructor;
    }

    public void setInstructor(faculty instructor) {
        this.instructor = instructor;
    }

    public List<student> getEnrolledStudents() {
        return enrolledStudents;
    }

    public void setEnrolledStudents(List<student> enrolledStudents) {
        this.enrolledStudents = enrolledStudents;
    }

    public int getMaxCapacity() {
        return maxCapacity;
    }

    public void setMaxCapacity(int maxCapacity) {
        this.maxCapacity = maxCapacity;
    }

}


