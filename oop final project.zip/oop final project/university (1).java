/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package alexuniversity;
import java.util.ArrayList;
import java.io.Serializable;

/**
 *
 * @author Lenovo
 */

public class university  implements Serializable {
    private ArrayList<department> departments = new ArrayList<>();
    private ArrayList<user> users = new ArrayList<>();
    private ArrayList<course> courses = new ArrayList<>();
 private static final String USERS_FILE = "users.txt";
private static final String COURSES_FILE = "courses.txt";
private static final String DEPARTMENTS_FILE = "departments.txt";


    public university() {
  
    users = new ArrayList<>(filemanger.loadData(USERS_FILE));
    courses = new ArrayList<>(filemanger.loadData(COURSES_FILE));
    departments = new ArrayList<>(filemanger.loadData(DEPARTMENTS_FILE));
}



  
    public void registerStudent(student student) {
        users.add(student);
        filemanger.saveData(users, USERS_FILE);
    }

    public void hireFaculty(faculty f) {
        users.add(f);
        filemanger.saveData(users, USERS_FILE);
    }

    public void addDepartment(department dept) {
        departments.add(dept);
       filemanger.saveData(departments, DEPARTMENTS_FILE);
    }

    public void addCourse(course course) {
        courses.add(course);
        filemanger.saveData(courses, COURSES_FILE);
    }

    public user authenticateUser(String username, String password) {
        for (user u : users) {
            if (u.login(username, password)) {
                return u;
            }
        }
        return null;
    }

    public ArrayList<user> getUsers() {
        return users;
    }

    public ArrayList<course> getCourses() {
        return courses;
    }

    public ArrayList<department> getDepartments() {
        return departments;
    }

    public void saveAll() {
      filemanger.saveData(users, USERS_FILE);
       filemanger.saveData(courses, COURSES_FILE);
      filemanger.saveData(departments, DEPARTMENTS_FILE);
    }

   
}