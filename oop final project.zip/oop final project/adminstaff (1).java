/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package alexuniversity;
import java.io.Serializable;

/**
 *
 * @author Lenovo
 */
public class adminstaff  extends user implements Serializable {
   private String staff_id;
    private String department;
    private String role;

    public adminstaff(String userid, String username, String password, String name, String email, String contactinfo) {
        super(userid, username, password, name, email, contactinfo);
    }
    

    public adminstaff(String staff_id, String department, String role, String userid, String username, String password, String name, String email, String contactinfo) {
        super(userid, username, password, name, email, contactinfo);
        this.staff_id = staff_id;
        this.department = department;
        this.role = role;
    }
     @Override
    public void showmenu() {
        System.out.println("\nAdmin Staff Menu:");
        System.out.println("1. Register student");
        System.out.println("2. Assign faculty to course");
        System.out.println("3. Manage departments");
        System.out.println("4. Logout");
    }

    public void registerstudent(student s) {
        System.out.println("Student " + s.getName() + " registered successfully.");
    }

    public void assignfaculty(course c, faculty f) {
        System.out.println("Faculty " + f.getName() + " assigned to course " + c.getTitle());
    }
    public course createCourse(String courseid, String title) {
        course c1 = new course(courseid,title);
        System.out.println("Created course: " + courseid + " - " + title);
        return c1;
    }
  
         public void generatereports(university university) {
        System.out.println("\n--- University Report ---");

        for (course c : university.getCourses()) {
            System.out.println("Course: " + c.getCourse_id() + " - " + c.getTitle());
            System.out.println("Instructor: " + (c.getInstructor() != null ? c.getInstructor().getName() : "Unassigned"));
            System.out.println("Enrolled Students: " + (c.getEnrolledStudents() != null ? c.getEnrolledStudents().size() : 0));
            System.out.println("-----------------------------------");
        }

        for (user u : university.getUsers()) {
            if (u instanceof student) {
                student s = (student) u;
                double gpa = s.calculateGPA();
                System.out.println("Student: " + s.getName() + ", GPA: " + gpa);
            }
        }
    
    
}

}