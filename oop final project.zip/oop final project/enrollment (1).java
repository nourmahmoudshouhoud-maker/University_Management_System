/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package alexuniversity;
import java.util.Date;
import java.io.Serializable;
/**
 *
 * @author Lenovo
 */
public class enrollment  implements Serializable{
   private student student;
    private course course ;
    private Date enrollment_date;
    private String grade;
    private String status;
   
    public enrollment() {
    }
    

    public enrollment(student student, course course,Date enrollment_Date, String grade, String status) {
        this.student = student;
        this.course = course;
        this.enrollment_date = enrollment_date;
        this.grade = grade;
        this.status = status;
    }

    public student getStudent() {
        return student;
    }

    public course getCourse() {
        return course;
    }

    public Date getEnrollment_date() {
        return enrollment_date;
    }

    public String getGrade() {
        return grade;
    }

    public String getStatus() {
        return status;
    }

    public void setStudent(student student) {
        this.student = student;
    }

    public void setCourse(course course) {
        this.course = course;
    }

    public void setEnrollment_date(Date enrollment_date) {
        this.enrollment_date = enrollment_date;
    }

    public void setGrade(String grade) {
        this.grade = grade;
    }

    public void setStatus(String status) {
        this.status = status;
    }
  public void assignGrade(String grade) {
        this.grade = grade;
        this.status = "Completed";
    }

    public void withdraw() {
        this.status = "Withdrawn";
    }
    
    
  
}