/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package alexuniversity;
import java.io.Serializable;

/**
 *
 * @author Lenovo
 */
public abstract class  user implements Serializable{
     protected String userid;
     protected String username;
     protected String password;
     protected String name;
     protected String email;
     protected String contactinfo;

    public user (String userid, String username, String password, String name, String email, String contactinfo) {
        this.userid = userid;
        this.username = username;
        this.password = password;
        this.name = name;
        this.email = email;
        this.contactinfo = contactinfo;
    } 
   public boolean login( String input_username , String input_password){
  
       return username.equals(input_username)&&password.equals(input_password);
     
   }
   public void logout(){
       System.out.println("loggout successfully");
   }
   public void updateprofile(String new_username,String new_password,String new_email){
   this.name=new_username;
   this.password=new_password;
   this.email=new_email;
   if (password.length() < 6) {
    System.out.println("Password must be at least 6 characters.");
}

   }
   public abstract void showmenu();
    
   public String tocv(){
       return "userid="+userid+",username="+username+",password="+password+",name="+name+",email="+email+",contactinfo="+contactinfo;
               }

    public String getUserid() {
        return userid;
    }

    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }

    public String getName() {
        return name;
    }

    public String getEmail() {
        return email;
    }

    public String getContactinfo() {
        return contactinfo;
    }

    public void setUserid(String userid) {
        this.userid = userid;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setContactinfo(String contactinfo) {
        this.contactinfo = contactinfo;
    }

    

}