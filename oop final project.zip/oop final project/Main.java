/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package alexuniversity;



/**
 *
 * @author nourm
 */
import java.util.Scanner;

    /**
     * @param args the command line arguments
     */

public class Main {
    
    private static university university = new university();
    private static Scanner scanner = new Scanner(System.in);
    private static void loadDummyData() {
     // Students 
    student s1 = new student("s1", "s1", "1234", "Ali Ahmed", "ali@student.com", "0123456789");
    student s2 = new student("s2", "s2", "1234", "Sara Mostafa", "sara@student.com", "0101234567");
    university.registerStudent(s1);
    university.registerStudent(s2);

    // Faculty
    faculty f1 = new faculty("f1", "f1", "1234", "Dr. Mona", "mona@faculty.com", "0111222333");
    faculty f2 = new faculty("f2", "f2", "1234", "Dr. Omar", "omar@faculty.com", "0109988776");
    university.getUsers().add(f1);
    university.getUsers().add(f2);

    //Admin Staff 
    adminstaff a1 = new adminstaff("a1", "a1", "1234", "Ms. Hoda", "hoda@admin.com", "0101122334");
    university.getUsers().add(a1);

    //System Admin 
    systemadmin admin = new systemadmin("admin001", 1, "admin", "admin", "admin", "System Admin", "admin@uni.com", "0120000111");
    university.getUsers().add(admin);

    // Courses
    course c1 = new course("CS101", "Intro to Programming", 3);
    c1.setSchedule("mon 12/10");
    university.getCourses().add(c1);
    f1.addcourse(c1);
    course c2 = new course("CS102", "Data Structures", 4);
    c2.setSchedule("wed 14/10");
    university.getCourses().add(c2);
     f1.addcourse(c2);
    course c3 = new course("CS103", "Databases", 3);
      c3.setSchedule("sat 10/10");
      university.getCourses().add(c3);
    // Student Course Registration 
    s1.registercourse(c1);
    s1.registercourse(c2);
    s2.registercourse(c1);
    s2.registercourse(c3);

    // Attendance
    s1.markAttendance(c1);
    s1.markAttendance(c2);
    s2.markAttendance(c1);
    s2.markAttendance(c3);

    // Grades 
    f1.assigngrade(s1, c1, "A");
    f1.assigngrade(s1, c2, "B+");
    f1.assigngrade(s2, c1, "B");
    f2.assigngrade(s2, c3, "A-");

    // You can also add logs or print confirmation
    System.out.println("✔ Dummy data loaded: 2 students, 2 faculty, 3 courses, attendance and grades set.");
}
    public static void main(String[] args) {
        System.out.println("=========== Alexandria University Management System ===========");

        boolean running = true;
        loadDummyData();

        while (running) {
            System.out.println("\nMain Menu:");
            System.out.println("1. Login");
            System.out.println("2. Exit");
            System.out.print("Choose an option: ");

            String choice = scanner.nextLine();

            switch (choice) {
                case "1":
                    loginProcess();
                    break;
                case "2":
                    System.out.println("Exiting the system. Goodbye!");
                    running = false;
                    break;
                default:
                    System.out.println("Invalid choice. Please select 1 or 2.");
            }
        }
    }
    private static void loginProcess() {
        System.out.println("\n--- User Login ---");
        System.out.print("Username: ");
        String username = scanner.nextLine();

        System.out.print("Password: ");
        String password = scanner.nextLine();

        user loggedUser = university.authenticateUser(username, password);

        if (loggedUser != null) {
            System.out.println("✅ Login successful. Welcome, " + loggedUser.getName() + "!");
            handleUserMenu(loggedUser);
        } else {
            System.out.println("❌ Invalid credentials. Please try again.");
        }
    }
    private static void handleUserMenu(user u) {
        if (u instanceof student) {
            handleStudentMenu((student) u);
        } else if (u instanceof faculty) {
            handleFacultyMenu((faculty) u);
        } else if (u instanceof adminstaff) {
            handleAdminMenu((adminstaff) u);
        } else if (u instanceof systemadmin) {
            handleSysAdminMenu((systemadmin) u);
        } else {
            System.out.println("⚠️ Unknown user type.");
        }
    }
    private static void handleStudentMenu(student s) {
        boolean back = false;
        while (!back) {
            s.showmenu();
            System.out.print("Select option: ");
            String option = scanner.nextLine();
            switch (option) {
                case "1":
                    System.out.print("Enter course ID: ");
                    course c1 = findCourseById(scanner.nextLine());
                    if (c1 != null) s.registercourse(c1);
                    else System.out.println("Course not found.");
                    break;
                case "2":
                    System.out.print("Enter course ID to drop: ");
                    course c2 = findCourseById(scanner.nextLine());
                    if (c2 != null) s.dropcourse(c2);
                    else System.out.println("Course not found.");
                    break;
                case "3":
                    s.viewGrades();
                    break;
                case "4":
                    s.calculateGPA();
                    break;
                case "5":
                    System.out.print("Enter course ID to mark attendance: ");
                    course c3 = findCourseById(scanner.nextLine());
                    if (c3 != null) s.markAttendance(c3);
                    else System.out.println("Course not found.");
                    break;
                case "6":
                    back = true;
                    s.logout();
                    break;
                default:
                    System.out.println("Invalid option.");
            }
        }
    }

    private static void handleFacultyMenu(faculty f) {
        boolean back = false;
        while (!back) {
            f.showmenu();
            System.out.print("Select option: ");
            String option = scanner.nextLine();
            switch (option) {
                case "1":
                    System.out.print("Enter course ID to manage: ");
                    course c1 = findCourseById(scanner.nextLine());
                    if (c1 != null) f.manageCourse(c1);
                    else System.out.println("Course not found.");
                    break;
                case "2":
                    System.out.print("Enter student username: ");
                    String studentUsername = scanner.nextLine();
                    System.out.print("Enter course ID: ");
                    String courseId = scanner.nextLine();
                    System.out.print("Enter grade: ");
                    String grade = scanner.nextLine();
                    student s = findStudentByUsername(studentUsername);
                    course c2 = findCourseById(courseId);
                    if (s != null && c2 != null) f.assigngrade(s, c2, grade);
                    else System.out.println("Student or course not found.");
                    break;
                case "3":
                    System.out.print("Enter course ID to view roster: ");
                    course c3 = findCourseById(scanner.nextLine());
                    if (c3 != null) f.viewStudentRoster(c3);
                    else System.out.println("Course not found.");
                    break;
                case "4":
                    f.generatePerformanceReport();
                    break;
                case "5":
                    back = true;
                    f.logout();
                    break;
                default:
                    System.out.println("Invalid option.");
            }
        }
    }

    private static void handleAdminMenu(adminstaff admin) {
        boolean back = false;
        while (!back) {
            admin.showmenu();
            System.out.print("Select option: ");
            String option = scanner.nextLine();
            switch (option) {
                case "1":
                    System.out.print("Enter student username: ");
                    String username = scanner.nextLine();
                    System.out.print("Password: ");
                    String password = scanner.nextLine();
                    System.out.print("Name: ");
                    String name = scanner.nextLine();
                    System.out.print("Email: ");
                    String email = scanner.nextLine();
                    System.out.print("Contact Info: ");
                    String contact = scanner.nextLine();
                    student newStudent = new student(username, username, password, name, email, contact);
                    university.registerStudent(newStudent);
                    System.out.println("✅ Student registered.");
                    break;
                case "2":
                    System.out.print("Enter course ID: ");
                    course c = findCourseById(scanner.nextLine());
                    System.out.print("Enter faculty username: ");
                    faculty f = findFacultyByUsername(scanner.nextLine());
                    if (c != null && f != null) {
                        admin.assignfaculty(c, f);
                        System.out.println("✅ Faculty assigned to course.");
                    } else {
                        System.out.println("Faculty or course not found.");
                    }
                    break;
                case "3":
                    admin.generatereports(university);
                    break;
                case "4":
                    back = true;
                    admin.logout();
                    break;
                default:
                    System.out.println("Invalid option.");
            }
        }
    }

    private static void handleSysAdminMenu(systemadmin admin) {
        boolean back = false;
        while (!back) {
            admin.showmenu();
            System.out.print("Select option: ");
            String option = scanner.nextLine();
            switch (option) {
                case "1":
                    System.out.print("User type (student/faculty/adminstaff): ");
                    String type = scanner.nextLine();
                    System.out.print("User ID: ");
                    String id = scanner.nextLine();
                    System.out.print("Username: ");
                    String username = scanner.nextLine();
                    System.out.print("Password: ");
                    String password = scanner.nextLine();
                    System.out.print("Name: ");
                    String name = scanner.nextLine();
                    System.out.print("Email: ");
                    String email = scanner.nextLine();
                    System.out.print("Contact: ");
                    String contact = scanner.nextLine();

                    user newUser = admin.createUser(type, id, username, password, name, email, contact);
                    if (newUser != null) {
                        university.getUsers().add(newUser);
                        System.out.println(type + " created successfully.");
                    }
                    break;
                case "2":
                    admin.modifysystemsettings();
                    break;
                case "3":
                    admin.backupData();
                    break;
                case "4":
                    System.out.print("Enter username: ");
                    user u = findUserByUsername(scanner.nextLine());
                    System.out.print("Enter new permission: ");
                    String perm = scanner.nextLine();
                    if (u != null) admin.managePermissions(u, perm);
                    else System.out.println("User not found.");
                    break;
                case "5":
                    back = true;
                    admin.logout();
                    break;
                default:
                    System.out.println("Invalid option.");
            }
        }
    }

    // Helper methods
    private static course findCourseById(String id) {
        for (course c : university.getCourses()) {
            if (c.getCourse_id().equalsIgnoreCase(id)) return c;
        }
        return null;
    }

    private static student findStudentByUsername(String username) {
        for (user u : university.getUsers()) {
            if (u instanceof student && u.getUsername().equalsIgnoreCase(username)) {
                return (student) u;
            }
        }
        return null;
    }

    private static faculty findFacultyByUsername(String username) {
        for (user u : university.getUsers()) {
            if (u instanceof faculty && u.getUsername().equalsIgnoreCase(username)) {
                return (faculty) u;
            }
        }
        return null;
    }

    private static user findUserByUsername(String username) {
        for (user u : university.getUsers()) {
            if (u.getUsername().equalsIgnoreCase(username)) {
                return u;
            }
        }
        return null;
    }
}
