/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package alexuniversity;
import java.io.Serializable;

/**
 *
 * @author Lenovo
 */
public class systemadmin extends user implements Serializable {
   private String  admin_id;
    private int security_level;

    public systemadmin(String admin_id, int security_level, String userid, String username, String password, String name, String email, String contactinfo) {
        super(userid, username, password, name, email, contactinfo);
        this.admin_id = admin_id;
        this.security_level = security_level;
    }

    public systemadmin(String admin_id, String userid, String username, String password, String name, String email, String contactinfo) {
        super(userid, username, password, name, email, contactinfo);
        this.admin_id = admin_id;
    }

    



    public String getAdmin_id() {
        return admin_id;
    }

    public int getSecurity_level() {
        return security_level;
    }
    
     @Override
    public void showmenu() {
        System.out.println("\nSystem Admin Menu:");
        System.out.println("1. Create user");
        System.out.println("2. Modify system settings");
        System.out.println("3. Backup data");
        System.out.println("4. manage permissions");
         System.out.println("5. Logout");
    }

   public user createUser(String type, String userId, String username, String password,
                           String name, String email, String contactInfo) {
        switch (type.toLowerCase()) {
            case "student":
                
                student newStudent = new student(userId, username, password, name, email, contactInfo);
                
                return newStudent;
            case "faculty":
                return new faculty(userId, username, password, name, email, contactInfo, "F" + userId);
            case "adminstaff":
                return new adminstaff(userId, username, password, name, email, contactInfo, "A" + userId, "Admin Dept", "Registrar");
            default:
                System.out.println("Invalid user type.");
                return null;
        }
      

        
   }
  public void modifysystemsettings() {
        System.out.println("System settings have been modified.");
    }

    public void backupData() {
        System.out.println("System data has been backed up.");
    }

    public void managePermissions(user user, String permission) {
        System.out.println("Permissions updated for user: " + user.getUsername() + " — New Permission: " + permission);
    }
}
