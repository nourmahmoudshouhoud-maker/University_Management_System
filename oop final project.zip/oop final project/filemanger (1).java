/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package alexuniversity;
import java.util.ArrayList;
import java.util.List;
import java.io.*;
import java.io.Serializable;
/**
 *
 * @author Lenovo
 */
public class filemanger  implements Serializable{
   public static <T> void saveData(List<T> dataList, String filename) {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(filename))) {
            oos.writeObject(dataList);
            System.out.println("Data saved to " + filename + " successfully.");
        } catch (IOException e) {
            System.out.println("Error saving data to " + filename + ": " + e.getMessage());
        }
    }

    // Load a list of objects from a file
    @SuppressWarnings("unchecked")
    public static <T> List<T> loadData(String filename) {
        List<T> dataList = new ArrayList<>();
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(filename))) {
            dataList = (List<T>) ois.readObject();
            System.out.println("Data loaded from " + filename + " successfully.");
        } catch (FileNotFoundException e) {
            System.out.println(filename + " not found. Loading empty list.");
        } catch (IOException | ClassNotFoundException e) {
            System.out.println("Error loading data from " + filename + ": " + e.getMessage());
        }
        return dataList;
        
    }

    // Save individual object to a file
    public static <T> void saveSingleObject(T object, String filename) {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(filename))) {
            oos.writeObject(object);
            System.out.println("Object saved to " + filename + " successfully.");
        } catch (IOException e) {
            System.out.println("Error saving object to " + filename + ": " + e.getMessage());
        }
    }

    // Load individual object from a file
    @SuppressWarnings("unchecked")
    public static <T> T loadSingleObject(String filename) {
        T object = null;
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(filename))) {
            object = (T) ois.readObject();
            System.out.println("Object loaded from " + filename + " successfully.");
        } catch (FileNotFoundException e) {
            System.out.println(filename + " not found.");
        } catch (IOException | ClassNotFoundException e) {
            System.out.println("Error loading object from " + filename + ": " + e.getMessage());
        }
        return object;
    }

    
    
   }

 
  

    