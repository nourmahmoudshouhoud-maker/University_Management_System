/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package alexuniversity;
import java .util.ArrayList;
import java .util.List;
import java.io.Serializable;

/**
 *
 * @author Lenovo
 */
public class faculty  extends user implements Serializable {
    private String facultyid;
    private String department;
    private String expertise;
    private List<course> courses_teaching;

    public faculty(String userid, String username, String password, String name, String email, String contactinfo, String par) {
        super(userid, username, password, name, email, contactinfo);
    }

    public faculty(String facultyid, String department, String expertise, String userid, String username, String password, String name, String email, String contactinfo) {
        super(userid, username, password, name, email, contactinfo);
        this.facultyid = facultyid;
        this.department = department;
        this.expertise = expertise;
      this.courses_teaching = new ArrayList<>();
    }

    public String getExpertise() {
        return expertise;
    }

    public List<course> getCourses_teaching() {
        return courses_teaching;
    }

    public String getFacultyid() {
        return facultyid;
    }

    public String getDepartment() {
        return department;
    }

    public String isExpertise() {
        return expertise;
    }

    public List<course> isCourses_teaching() {
        return courses_teaching;
    }

    public void setFacultyid(String facultyid) {
        this.facultyid = facultyid;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public void setExpertise(String expertise) {
        this.expertise = expertise;
    }

    public void setCourses_teaching(List<course> courses_teaching) {
        this.courses_teaching = courses_teaching;
    }

    @Override
    public void showmenu() {
        System.out.println("\nFaculty Menu:");
        System.out.println("1. Manage courses");
        System.out.println("2. Assign grades");
        System.out.println("3. View student rosters");
        System.out.println("4. View performance report");
        System.out.println("5. Logout");
    }
public faculty(String userid, String username, String password, String name, String email, String contactinfo) {
    super(userid, username, password, name, email, contactinfo);
    this.facultyid=facultyid;

    this.department = "General";
    this.expertise = "Unknown";
    this.courses_teaching = new ArrayList<>();
}


    public void assigngrade(student s, course c, String grade) {
        for (enrollment e : s.getEnrollments()) {
            if (e.getCourse().equals(c) && e.getStatus().equals("Active")) {
                e.assignGrade(grade);
                System.out.println("Grade " + grade + " assigned to " + s.getName() + " for course " + c.getTitle());
                return;
            }
        }
        System.out.println("Student is not enrolled in this course or already completed/withdrawn.");
    }

    public void manageCourse(course course) {
        System.out.println("Managing course: " + course.getCourse_id() + ":");
    }

    public void setOfficeHours(String time) {
        System.out.println("Office hours set to: " + time);
    }

    public void viewStudentRoster(course course) {
        System.out.println("Student roster for " + course.getCourse_id() + ":");
        for (student s : course.getEnrolledStudents()) {
            System.out.println("- " + s.getName());
        }
    }

    public void generatePerformanceReport() {
        System.out.println("\n--- Faculty Performance Report ---");
        for (course c : courses_teaching) {
            int passed = 0;
            int total = 0;
            double totalPoints = 0;

            for (student s : c.getEnrolledStudents()) {
                for (enrollment e : s.getEnrollments()) {
                    if (e.getCourse().equals(c) && e.getGrade() != null) {
                        total++;
                        String grade = e.getGrade().toUpperCase();
                        switch (grade) {
                            case "A": totalPoints += 4; passed++; break;
                            case "B": totalPoints += 3; passed++; break;
                            case "C": totalPoints += 2; passed++; break;
                            case "D": totalPoints += 1; break;
                            case "F": totalPoints += 0; break;
                        }
                    }
                }
            }

            double avgGPA = (total > 0) ? totalPoints / total : 0.0;
            System.out.println("Course: " + c.getTitle());
            System.out.println("- Total Students Graded: " + total);
            System.out.println("- Passed: " + passed);
            System.out.printf("- Average Grade Point: %.2f\n", avgGPA);
        }
    }

   public void addcourse(course course) {
    if (!courses_teaching.contains(course)) {
        courses_teaching.add(course);
        System.out.println("✅ Course " + course.getCourse_id() + " added to faculty " + getName());
    } else {
        System.out.println("⚠️ Course already assigned to this faculty.");
    }
}

    
}