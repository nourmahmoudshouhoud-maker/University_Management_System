/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package alexuniversity;
import java.util.ArrayList;
import java.util.List;
import java.io.Serializable;

/**
 *
 * @author Lenovo
 */
public class department  implements Serializable {
    private int department_id;
    private String name ;
    private String faculty;
    private String offered_courses;
     private List<faculty> facultyList = new ArrayList<>();
    private List<course> coursesOffered = new ArrayList<>(); 

    public department() {
    }
    

    public department(int department_id, String name, String faculty, String offered_courses) {
        this.department_id = department_id;
        this.name = name;
        this.faculty = faculty;
        this.offered_courses = offered_courses;
    }
      public void addFaculty(faculty faculty) {
        facultyList.add(faculty);
    }

    public void addCourse(course course) {
        coursesOffered.add(course);
    }
    
}
